from django.apps import AppConfig


class EcommerceappConfig(AppConfig):
    name = 'ecommerceapp'
